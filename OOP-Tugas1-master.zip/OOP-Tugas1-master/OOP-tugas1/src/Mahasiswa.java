
public class Mahasiswa {

    public static void main(String[] args) {
        main mhs = new main();
        mhs.nama = " Aditya Yudha Remarais";
        mhs.nim = "18090021";
        mhs.kelas = "4B";
        
        System.out.println("Nama = "+mhs.nama);
        System.out.println("Nim = "+mhs.nim);
        System.out.println("Kelas = "+mhs.kelas);
    }
    
}
