
public class main {
    String nama,nim,kelas ;
}
